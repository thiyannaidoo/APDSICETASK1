import express from "express";
const PORT = 3000;
const app = express();
const urlprefix = '/api';

app.use(express,json());



app.get(urlprefix+'/',(req,res)=>{
    res.send('I am figuring this out')
})

app.get(urlprefix+'orders',(req,res)=>{
const orders = [

{
    id: "1",
    name: "orange"
},

{
    id: "2",
    name: "apple"
},

{
    id: "3",
    name: "pear"
}

]
res.json(
    {
    messaage:"Fruites",
    oerders:orders
}

)



})

app.listen(PORT);